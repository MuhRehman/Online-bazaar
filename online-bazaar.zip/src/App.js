import Registration from "./components/Registration.jsx";
import './App.css';
 

function App() {
  return (
    <div className="App">
 
      <Registration ></Registration>
    </div>
  );
}

export default App;
